<?php
$a='red';
?>
<!doctype html>
<html>
<head>
	<title><?php
	echo $a;
	?>
	</title>
</head>
<body>
</body>
</html>
