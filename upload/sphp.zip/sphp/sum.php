<?php
$a=10;
$b=20;
echo"sum is" .($a + $b);
?>