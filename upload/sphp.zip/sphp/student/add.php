<!doctype html>
<html>
<head>
<title>add.php</title>
</head>
<body>
<form action="addprocess.php" method="POST">
Email<input type="email" name="email" required/>
<br>
Password<input type="Password" name="password" required/><br>
<input type="submit" value="ADD"/>
</form>
</body>
</html>
