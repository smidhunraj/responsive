<?php
//print_r($_POST);
include "scon.php";
$email=$_POST['email'];
$password=$_POST['password'];
$sql="select * from student;";
$result=mysqli_query($link,$sql);
$sql=sprintf("INSERT INTO student set email='%s',password='%s'",$email,$password);
mysqli_query($link,$sql);
header("location:sindex.php");
?>