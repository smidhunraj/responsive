<?php
include "scon.php";
//$result=get_all_students();
$id=$_GET['id'];
$sql=sprintf("DELETE from student where id='%s'",$id);
mysqli_query( $link,$sql);
header("location:sindex.php");
?>