<?php
include "scon.php";
$sql="select * from student ;";
$result=mysqli_query($link,$sql);
if(mysqli_num_rows($result)>0){
	?> 
	<table border="1">
	<tr><th>Id</th>
	<th>Email</th>
	<th>Password</th>
	
    <th>Datecreated</th>
    <th>Datemodified</th>
    <th> <a href="add.php">Add</a></th>
	</tr>
	<?php
	while($row=mysqli_fetch_assoc($result)){
			?>
	<tr>
	<td> <?php echo $row['id'];?> </td>
	<td> <?php echo $row['email'];?> </td>
	<td> <?php echo $row['password'];?> </td>
	<td> <?php echo $row['datecreated'];?> </td>
    <td> <?php echo $row['datemodified'];?> </td>
   <td>
    
    <a href="edit.php?id=<?php echo $row['id'];?>">edit/</a> <a href="delete.php?id=<?php echo $row['id'];?> ">delete</a> </td>
    


    

	</tr>
<?php
}
?>
</table>
<?php
}else
{
	echo "no recourd found";
}
?>