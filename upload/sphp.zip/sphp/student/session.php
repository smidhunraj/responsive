<?php
session_start();

$email=$_POST['email'];
$password="hello";//$_POST['password'];
//include "scon.php";
//$sql=sprintf("select * from student where email='%s'and password='%s'",$email,$password);
//$result=mysql_query($link,$sql);
//if(mysqli_num_rows($result)>0)
	{
//$row=mysqli_fetch_assoc($result);
$_SESSION['email']=$email;//$row;
//header("location:admin.php");
	}
//else
//header("location:sindex.php");
?>