<!doctype html>
<html>
<head>
<title>edit</title>
</head>
<body>
<?php
include "scon.php";
$id=$_GET['id'];
$sql=sprintf("SELECT * FROM student where id='%s'",$id);
$result=mysqli_query($link,$sql);

$row=mysqli_fetch_assoc($result);
//print_r($row);
?>
<form action="eprocess.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id'];?>"/><br>
Email <input type="email" name="email" value="<?php echo $row['email'];?>"/><br>
Password<input type="password" name="password" value="<?php echo $row['password'];?>"/><br>
<input type="submit" value="update"/>
</form>
</body>
</html>
