<?php
include "scon.php";
$id=$_POST['id'];
$email=$_POST['email'];
$password=$_POST['password'];

$sql=sprintf("UPDATE student set email='%s',password='%s' where id='%s'",$email,$password,$id);
mysqli_query($link,$sql);
//sprint_r($row);
header("location:sindex.php");
?>