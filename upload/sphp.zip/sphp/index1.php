<?php
include"logcon.php";
$sql="select * from users;";
$result=mysqli_query($link,$sql);
if (mysqli_numrows($result)>0)
{
	?>
	<table border="1">
	<tr><th>Id</th>
	<th>Password</th></tr>
	<?php
	while($row=mysqli_fech assoc($result))
		{?>
	<tr>
	<td> <?php echo $row['id'];?> </td>
	<td> <?php echo $row['email'];?> </td>
	<td> <?php echo $row['password'];?> </td>
	</tr>
	<?php
}?>
</table>
<?php

}
else
{
	echo "no recourd found";
}
?>