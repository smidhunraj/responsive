<?php
$dbname="login";
$dbuser="root";
$dbpassword="";
$dbhost="localhost";
$link=mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
if($link ==null)
{
	echo "connect to db is faild";
} 
?>