<?php

echo"first no:"
echo"second  no:"
echo "sum is" .($a+$b);
?>