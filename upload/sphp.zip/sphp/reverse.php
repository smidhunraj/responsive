<?php
echo 'the first 10 numbers in reverse order:';
echo"<br>";
for($i=10;$i>=0;$i--)
{

print $i;
print"<br>";

}

?>