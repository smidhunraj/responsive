<?php
$a='red';
$b='green';
$c='#ccc';
?>
<!doctype html>
<html>
<head>
	<title><?php
	echo $a;
	?>
	</title>
</head>
<body bgcolor="<?php echo $b;?>">
<font color="<?php echo $c;?>">
Hello</font>

 
</body>
</html>
