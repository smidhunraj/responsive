<?php
include"logcon.php";
$sql="select *  from users1;";
$result=mysqli_query($link,$sql);
if(mysqli_num_rows($result)>0){
	?> 
	<table border="1">
	<tr><th>Id</th>
	<th>Email</th>
	<th>Password</th>
	<th>Add</th>
    <th>Datecreated</th>
    <th>Datemodified</th>
	</tr>
	<?php
	while($row=mysqli_fetch_assoc($result)){
			?>
	<tr>
	<td> <?php echo $row['id'];?> </td>
	<td> <?php echo $row['email'];?> </td>
	<td> <?php echo $row['password'];?> </td>
	<
   <td>
    
    <a href="edit.php">edit/</a> <a href="delete.php">delete</a> </td>
    
td> <?php echo $row['datecreated'];?> </td>
    <td> <?php echo $row['datemodified'];?> </td>

    

	</tr>
<?php
}
?>
</table>
<?php
}else
{
	echo "no recourd found";
}
?>