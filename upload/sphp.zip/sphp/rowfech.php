<?php
include"database.php";

$sql="select * from student";
$result=mysqli_query($link,$sql);
$rcount=mysqli_num_rows($result);
if($rcount>0){
	while($row=mysqli_fetch_assoc($result))
	{
		print "<pre>"; print_r($row);
	}
}else{
	print "no records found";
}
?>