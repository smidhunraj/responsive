<?php
$pers[0]=array('fname'=>'Nishu ','lname'=>'Das','age'=>18,'gender'=>'female');
$pers[1]=array('fname'=>'Manu','lname'=>'Mohan','age'=>20,'gender'=>'male');
print'<pre>';
print_r($pers);
?>