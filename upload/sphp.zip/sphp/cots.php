<?php
$n=10;
$a="Anu";
$m=15;
$b='Binu';
print "$a is $n years old";
print '$b is $m years old';
?>