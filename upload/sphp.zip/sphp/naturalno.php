<?php
//$n=10;
echo 'the first 10 natural numbers are:';
echo"<br>";
for($i=1;$i<11;$i++)
{

print $i;
print"<br>";

}

?>