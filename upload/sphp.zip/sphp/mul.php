<?php
$n=7;
echo"the multiplication table is";
echo"<br>";
for($i=1;$i<11;$i++)

{
	
	echo"$n x $i=".($n * $i);
	echo"<br>";
}
?>