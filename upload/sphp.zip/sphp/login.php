<?php
include"logcon.php";
$email= $_POST['email'];
$flag=0;
$password= $_POST['password'];
$sql="select * from users;"; 
$result=mysqli_query($link,$sql);
$rcount=mysqli_num_rows($result);
if($rcount>0){
	while($row=mysqli_fetch_assoc($result)){
		echo "<pre>";

if($row['email']==$email && $row['password']==$password)
     	{
     		$flag=1;
     	 echo "logged in";
     }


	}	

}
if($flag==0)
	echo "incorrect name OR password";
?>





