<?php
$num=array();
$num[]=10;
$num[]=20;
$num[]=30;
echo count($num);
?>