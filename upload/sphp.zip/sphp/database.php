<?php
$dbname="school";
$dbuser="root";
$dbpassword="";
$dbhost="localhost";
$link=mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
if($link ==null)
{
	echo mysql_error();
}
	
?>