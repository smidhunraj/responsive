<?php
$pers[0]['no']=1;
$pers[0]['fname']='Nishu';
$pers[0]['lname']='Das';
$pers[0]['age']=18;
$pers[0]['gender']='female';

$pers[1]['no']=2;
$pers[1]['fname']='Manu';
$pers[1]['lname']='Mohan';
$pers[1]['age']=20;
$pers[1]['gender']='male';

print'<pre>';
print_r($pers);
?>