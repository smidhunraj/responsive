<?php
$a='red';
$b='green';
?>
<!doctype html>
<html>
<head>
	<title><?php
	echo $a;
	?>
	</title>
</head>
<body bgcolor="<?php echo $b;?>" >
</body>
</html>
