<?php
//print_r($_GET);
$a=$_GET['n1'];
$b=$_GET['n2'];
$c=$a+$b;

echo $c;
?>