<!doctype html>
<html>
<head>
<title>login</title>
</head>
<body>
<form action="loginprocess.php" method="POST">
Email<input type="email" name="email" required/>
<br>
Password<input type="Password" name="password" required/><br>
<input type="submit" value="LOGIN"/>
</form>
</body>
</html>
