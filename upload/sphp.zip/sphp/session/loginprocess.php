<?php
session_start();
/*
Array ( [email] => soni@gmail.com [password] => 123 
print_r($_POST);
*/
$email=$_POST['email'];
$password=$_POST['password'];
 echo $sql=sprintf("SELECT * FROM student WHERE email='%s' and password='%s'",$email,$password);
?>