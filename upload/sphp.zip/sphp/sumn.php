<?php
//$n=10;
$s=0;
echo 'Sum of first 10 natural numbers:';

for($i=1;$i<11;$i++)


 $s=$s + $i;
print $s;


?>